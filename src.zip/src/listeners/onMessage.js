const {
  Events,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
} = require("discord.js");
const path = require("path");
const { clientPrefix } = require("../lib/config.json");
const afkManager = require("../lib/afkManager");
const prefixManager = require("../lib/prefixManager");
const EMOJIS = require("../lib/emojis");
const mentionCanvas = require("../lib/mentionCanvas");
/** @type {import('../lib/types/index.ts').Event} */

const levelingManager = require("../lib/levelingManager");

module.exports = {
  name: "onMessage",
  event: Events.MessageCreate,
  once: false,

  async execute(client, message) {
    if (!message.channel.isTextBased()) return;
    if (message.author.bot || !message.guild) return;

    // Process Leveling XP
    levelingManager.handleMessageXp(client, message).catch(() => null);

    const guildPrefix = prefixManager.getPrefix(message.guild.id);

    // AFK Check & Clear trigger for author
    const isAfkCommand = message.content
      .toLowerCase()
      .startsWith(`${guildPrefix}afk`);
    if (!isAfkCommand) {
      const authorAfk = afkManager.checkAFK(
        message.author.id,
        message.guild.id,
      );
      if (authorAfk) {
        afkManager.removeAFK(message.author.id);
        const duration = Date.now() - authorAfk.timestamp;
        const seconds = Math.floor((duration / 1000) % 60);
        const minutes = Math.floor((duration / (1000 * 60)) % 60);
        const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
        const days = Math.floor(duration / (1000 * 60 * 60 * 24));
        let durationStr = "";
        if (days > 0) durationStr += `${days}d `;
        if (hours > 0) durationStr += `${hours}h `;
        if (minutes > 0) durationStr += `${minutes}m `;
        durationStr += `${seconds}s`;

        const container = new ContainerBuilder().addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `### <:red_star:1539875482680696834> Welcome Back, ${message.author.username}!\n` +
              `-# *Your AFK status has been successfully cleared.*\n\n` +
              `> - **Duration:** \`${durationStr}\`\n` +
              `> - **Reason was:** \`${authorAfk.reason}\``,
          ),
        );

        await message
          .reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [], repliedUser: false },
          })
          .catch(() => null);
      }
    }

    // AFK Mention check
    if (message.mentions.users.size > 0) {
      const afkUsers = [];
      for (const [id, user] of message.mentions.users) {
        if (id === message.author.id || user.bot) continue;
        const afkInfo = afkManager.checkAFK(id, message.guild.id);
        if (afkInfo) {
          afkUsers.push({ user, afkInfo });
        }
      }

      if (afkUsers.length > 0) {
        const lines = afkUsers.map(({ user, afkInfo }) => {
          return `> - **${user.username}** is AFK: \`${afkInfo.reason}\` (<t:${Math.floor(afkInfo.timestamp / 1000)}:R>)`;
        });

        const container = new ContainerBuilder().addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `### <:Sleepy:1539875521326751825> Away From Keyboard\n` +
              `-# *The following mentioned users are currently away:*\n\n` +
              lines.join("\n"),
          ),
        );

        await message
          .reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [], repliedUser: false },
          })
          .catch(() => null);
      }
    }

    // Check if the message is a pure mention of the bot
    const mentionRegex = new RegExp(`^<@!?${client.user.id}>$`);
    if (mentionRegex.test(message.content.trim())) {
      const rawPing = client.ws.ping;
      const wsLatency = rawPing >= 0 ? rawPing : 24;
      const memberCount = message.guild.memberCount.toLocaleString();
      const serverCount = client.guilds.cache.size.toLocaleString();
      const commandCount = client.messageCommands.size;

      // Format Uptime
      const duration = client.uptime || 0;
      const seconds = Math.floor((duration / 1000) % 60);
      const minutes = Math.floor((duration / (1000 * 60)) % 60);
      const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
      const days = Math.floor(duration / (1000 * 60 * 60 * 24));
      let uptimeStr = "";
      if (days > 0) uptimeStr += `${days}d `;
      if (hours > 0) uptimeStr += `${hours}h `;
      if (minutes > 0) uptimeStr += `${minutes}m `;
      uptimeStr += `${seconds}s`;

      const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${client.user.id}`;

      // Generate dynamic metallic canvas card
      const cardBuffer = await mentionCanvas.generateMentionCard({
        client,
        guild: message.guild,
        guildPrefix,
        wsLatency,
        memberCount,
        serverCount,
        commandCount,
        uptimeStr,
      });

      const bannerAttachment = new AttachmentBuilder(cardBuffer, {
        name: "mention_card.png",
      });

      // Media Gallery (Wide Banner)
      const mediaItem = new MediaGalleryItemBuilder().setURL(
        "attachment://mention_card.png",
      );
      const mediaGallery = new MediaGalleryBuilder().addItems(mediaItem);

      // Pikachu or friendly greeting emoji
      const pikaEmoji =
        client.emojis.cache.find((e) =>
          e.name.toLowerCase().includes("pika"),
        ) || "⚡";

      // Styled Content matching reference
      const mainContent =
        `## ${pikaEmoji} Hey <@${message.author.id}> !\n\n` +
        `I'm **${client.user.username}**, your server assistant.\n\n` +
        `${EMOJIS.prefix || "⚡"} **Prefix :-** \`${guildPrefix}\`\n` +
        `🟢 **Help :-** \`${guildPrefix}help\`\n` +
        `${EMOJIS.signal || "📶"} **Ping :-** \`${wsLatency}ms\`\n` +
        `${EMOJIS.command || "⌨️"} **Commands :-** \`${commandCount}\`\n` +
        `${EMOJIS.members || "👥"} **Members :-** \`${memberCount}\`\n` +
        `🟢 **Status :-** \`Online\``;

      // Footer Text
      const footerContent = `-# Powered By Astrix Development.`;

      // Buttons Action Row
      const supportButton = new ButtonBuilder()
        .setLabel("Support")
        .setStyle(ButtonStyle.Link)
        .setURL("https://discord.gg/FR9pXG2Mwb");

      const inviteButton = new ButtonBuilder()
        .setLabel("Invite")
        .setStyle(ButtonStyle.Link)
        .setURL(inviteUrl);

      const row = new ActionRowBuilder().addComponents(
        supportButton,
        inviteButton,
      );

      // Build the final container
      const container = new ContainerBuilder()
        .addMediaGalleryComponents(mediaGallery)
        .addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true),
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(mainContent),
        )
        .addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true),
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(footerContent),
        )
        .addActionRowComponents(row);

      return message.reply({
        components: [container],
        files: [bannerAttachment],
        flags: MessageFlags.IsComponentsV2,
      });
    }

    // Blacklist Check
    const noprefixManager = require("../lib/noprefixManager");
    const blInfo = noprefixManager.isBlacklisted(
      message.author.id,
      message.guild.id,
    );
    if (blInfo.isBlacklisted) {
      const blContainer = new ContainerBuilder().addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `### 🚫 **Access Denied (Blacklisted)**\n` +
            `-# *Your access to Astrix command system has been restricted by bot administrators.*\n\n` +
            `> - **Reason:** \`${blInfo.reason}\``,
        ),
      );
      return message
        .reply({
          components: [blContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [], repliedUser: false },
        })
        .catch(() => null);
    }

    let usedPrefix = null;
    const mentionPrefixPattern = new RegExp(`^<@!?${client.user.id}>\\s*`);

    const memberRoleIds = message.member?.roles?.cache?.map((r) => r.id) || [];
    const userHasNoPrefix = noprefixManager.hasNoPrefix(
      message.author.id,
      message.guild.id,
      memberRoleIds,
      client,
    );

    const customRolesManager = require("../lib/customRolesManager");
    const crConfig = customRolesManager.getGuildConfig(
      client,
      message.guild.id,
    );
    const crAliases = crConfig?.aliases ? Object.keys(crConfig.aliases) : [];

    const contentTrimmed = message.content.trim();
    const firstWordRaw = contentTrimmed.split(/ +/g)[0]?.toLowerCase() || "";
    const firstWordClean = firstWordRaw.replace(/^[.\-!]+/, "");

    if (message.content.startsWith(guildPrefix)) {
      usedPrefix = guildPrefix;
    } else if (mentionPrefixPattern.test(message.content)) {
      const match = message.content.match(mentionPrefixPattern);
      usedPrefix = match[0];
    } else if (userHasNoPrefix) {
      if (firstWordRaw) {
        const potentialCmd =
          client.messageCommands.get(firstWordRaw) ||
          client.messageCommands.find((c) => c.alias?.includes(firstWordRaw));

        const isCrAlias =
          crAliases.includes(firstWordRaw) ||
          crAliases.includes(firstWordClean);

        if (potentialCmd || isCrAlias) {
          usedPrefix = "";
          noprefixManager.incrementExecutionCount();
        }
      }
    }

    if (usedPrefix === null) return;

    const [cmdRaw, ...args] = message.content
      .slice(usedPrefix.length)
      .trim()
      .split(/ +/g);
    const cmd = cmdRaw.toLowerCase();
    const Command =
      client.messageCommands.get(cmd) ||
      client.messageCommands.find((c) => c.alias?.includes(cmd));

    if (!Command) {
      await customRolesManager.executeAlias(client, message, cmd, args);
      return;
    }
    if (Command.devOnly && !client.developer.includes(message.author.id))
      return;

    const serverManager = require("../lib/serverManager");
    const cmdName = Command.alias?.[0] || cmd;
    const catName = Command.category;

    if (!client.developer.includes(message.author.id)) {
      if (
        cmdName !== "disable" &&
        cmdName !== "enable" &&
        serverManager.isCommandDisabled(
          message.guild.id,
          message.channel.id,
          cmdName,
          catName,
        )
      ) {
        if (serverManager.getDisableNotice(message.guild.id)) {
          const disContainer = new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `### 🚫 Command Disabled\n` +
                `-# *The command \`${cmd}\` is disabled in this channel or server.*`,
            ),
          );
          return message
            .reply({
              components: [disContainer],
              flags: MessageFlags.IsComponentsV2,
              allowedMentions: { parse: [], repliedUser: false },
            })
            .catch(() => null);
        }
        return;
      }

      if (Command.userPermissions && Command.userPermissions.length !== 0) {
        if (!message.member.permissions.has(Command.userPermissions)) {
          const perms = Array.isArray(Command.userPermissions)
            ? Command.userPermissions.join(", ")
            : Command.userPermissions;
          const container = new ContainerBuilder().addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `### ${EMOJIS.red_star || "⭐"} Permission Required\n` +
                `-# *Access denied due to missing user permissions.*\n\n` +
                `> - **Required Permission(s):** \`${perms}\``,
            ),
          );
          return message
            .reply({
              components: [container],
              flags: MessageFlags.IsComponentsV2,
              allowedMentions: { parse: [], repliedUser: false },
            })
            .catch(() => null);
        }
      }
    }
    if (Command.botPermissions && Command.botPermissions.length !== 0) {
      if (!message.guild.members.me.permissions.has(Command.botPermissions)) {
        const perms = Array.isArray(Command.botPermissions)
          ? Command.botPermissions.join(", ")
          : Command.botPermissions;
        const container = new ContainerBuilder().addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `### ${EMOJIS.red_star || "⭐"} Bot Permission Required\n` +
              `-# *Action blocked: Bot lacks required server permissions.*\n\n` +
              `> - **Missing Permission(s):** \`${perms}\``,
          ),
        );
        return message
          .reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [], repliedUser: false },
          })
          .catch(() => null);
      }
    }

    Command.execute(client, message, args);
  },
};
