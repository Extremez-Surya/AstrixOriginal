const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MessageFlags,
  AttachmentBuilder,
  SectionBuilder,
  ThumbnailBuilder,
} = require("discord.js");

module.exports = {
  alias: ["modstats", "modstat", "moderatorstats"],
  category: "Moderation",
  desc: "View moderation statistics and action telemetry for a moderator.",

  botPermissions: ["SendMessages"],
  userPermissions: ["ManageMessages"],
  devOnly: false,

  async execute(client, message, args) {
    let targetUser = message.mentions.users.first();
    if (!targetUser && args[0]) {
      try {
        targetUser = await client.users.fetch(args[0]);
      } catch (e) {}
    }
    if (!targetUser) targetUser = message.author;

    const member = await message.guild.members
      .fetch(targetUser.id)
      .catch(() => null);

    const isMod =
      member?.permissions.has("ManageMessages") ||
      member?.permissions.has("KickMembers") ||
      member?.permissions.has("BanMembers");

    const tickEmoji = "<:tick:1539875604248141825>";
    const crossEmoji = "<:cross:1539875608463548426>";

    const content = [
      `### <:rshield:1539875466939338773> Moderation Telemetry ── ${targetUser.username}`,
      `-# *Server staff activity and moderation standing.*`,
      "",
      `> <:stats:1539875420256866314> **Moderator Overview**`,
      `> - **Target Staff:** ${targetUser} (\`${targetUser.id}\`)`,
      `> - **Staff Standing:** ${isMod ? "`Active Staff Member` <:online:1539875424144859239>" : "`Regular Member` <:offline:1539875436690153474>"}`,
      `> - **Highest Role:** ${member?.roles.highest ? `<@&${member.roles.highest.id}>` : "\`None\`"}`,
      "",
      `> <:red_star:1539875482680696834> **Permissions Telemetry**`,
      `> - **Administrator:** \`${member?.permissions.has("Administrator") ? "Yes" : "No"}\` ${member?.permissions.has("Administrator") ? tickEmoji : crossEmoji}`,
      `> - **Ban Members:** \`${member?.permissions.has("BanMembers") ? "Yes" : "No"}\` ${member?.permissions.has("BanMembers") ? tickEmoji : crossEmoji}`,
      `> - **Kick Members:** \`${member?.permissions.has("KickMembers") ? "Yes" : "No"}\` ${member?.permissions.has("KickMembers") ? tickEmoji : crossEmoji}`,
      `> - **Manage Messages:** \`${member?.permissions.has("ManageMessages") ? "Yes" : "No"}\` ${member?.permissions.has("ManageMessages") ? tickEmoji : crossEmoji}`,
      `> - **Manage Channels:** \`${member?.permissions.has("ManageChannels") ? "Yes" : "No"}\` ${member?.permissions.has("ManageChannels") ? tickEmoji : crossEmoji}`,
      `> - **Moderate Members (Timeout):** \`${member?.permissions.has("ModerateMembers") ? "Yes" : "No"}\` ${member?.permissions.has("ModerateMembers") ? tickEmoji : crossEmoji}`,
    ].join("\n");

    const files = [];
    const container = new ContainerBuilder();
    const avatarUrl = targetUser.displayAvatarURL({
      extension: "png",
      size: 512,
    });

    if (avatarUrl) {
      try {
        const avatarAttachment = new AttachmentBuilder(avatarUrl, {
          name: "staff_avatar.png",
        });
        files.push(avatarAttachment);

        const section = new SectionBuilder()
          .setThumbnailAccessory(
            new ThumbnailBuilder().setURL("attachment://staff_avatar.png"),
          )
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content),
          );

        container.addSectionComponents(section);
      } catch (e) {
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(content),
        );
      }
    } else {
      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(content),
      );
    }

    container
      .addSeparatorComponents(
        new SeparatorBuilder()
          .setSpacing(SeparatorSpacingSize.Small)
          .setDivider(true),
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `-# *Powered by ASTRIXCODE™ • © 2026 ASTRIXCODE*`,
        ),
      );

    return message
      .reply({
        components: [container],
        files: files,
        flags: MessageFlags.IsComponentsV2,
      })
      .catch(() => null);
  },
};
