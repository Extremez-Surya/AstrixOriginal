const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require("discord.js");
const levelingManager = require("../../lib/levelingManager");
const EMOJIS = require("../../lib/emojis");

module.exports = {
  alias: ["setlevel"],
  category: "Leveling",
  desc: "Set a member's experience level manually.",
  botPermissions: ["SendMessages", "ManageRoles"],
  userPermissions: ["ManageGuild"],
  devOnly: false,

  async execute(client, message, args) {
    const targetUser = message.mentions.users.first();
    const newLevel = parseInt(args[1] || args[0], 10);

    if (!targetUser || isNaN(newLevel) || newLevel < 0) {
      const container = new ContainerBuilder().addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `### ⚙️ Level Management\n` +
          `-# *Adjust member XP level manually.*\n\n` +
          `> - **Usage:** \`.setlevel @user <level_number>\``
        )
      );
      return message
        .reply({ components: [container], flags: MessageFlags.IsComponentsV2 })
        .catch(() => null);
    }

    const guildId = message.guild.id;
    const memberData = levelingManager.getMemberData(guildId, targetUser.id);

    // Calculate total cumulative XP for new level
    let totalAccumulated = 0;
    for (let l = 0; l < newLevel; l++) {
      totalAccumulated += levelingManager.xpToNextLevel(l);
    }

    memberData.level = newLevel;
    memberData.xp = 0;
    memberData.totalXp = totalAccumulated;

    levelingManager.setMemberData(guildId, targetUser.id, memberData);

    // Apply role rewards
    const targetMember = await message.guild.members.fetch(targetUser.id).catch(() => null);
    if (targetMember) {
      await levelingManager.applyRewards(client, guildId, memberData, targetMember);
    }

    const container = new ContainerBuilder().addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `### ${EMOJIS.success || "✅"} Member Level Updated\n` +
        `-# *XP data modified and role rewards synchronized.*\n\n` +
        `> - **Target User:** ${targetUser}\n` +
        `> - **New Level:** \`${newLevel}\`\n` +
        `> - **Total XP:** \`${totalAccumulated.toLocaleString()} XP\``
      )
    );

    return message
      .reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [], repliedUser: false },
      })
      .catch(() => null);
  },
};
