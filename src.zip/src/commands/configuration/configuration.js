const { MessageFlags, PermissionFlagsBits } = require("discord.js");
const noprefixManager = require("../../lib/noprefixManager");
const { buildConfigurationContainer } = require("../../lib/security/handleConfigurationInteraction");

module.exports = {
  name: "configuration",
  alias: ["configuration", "config", "serverconfig", "settings"],
  category: "Configuration",
  desc: "Master Server Configuration Hub (Triggers, Auto-Reactions, Sticky Messages & Server Settings).",
  botPermissions: ["SendMessages"],
  userPermissions: ["ManageGuild"],
  devOnly: false,

  async execute(client, message, args) {
    if (!message.guild) return;

    const isMemberPermitted = message.member?.permissions.has(PermissionFlagsBits.ManageGuild);
    const isBotOwner = noprefixManager.isOwner(message.author.id, client);

    if (!isMemberPermitted && !isBotOwner) {
      return message.reply({
        content: "❌ You need **Manage Server** permission to view or edit server configuration.",
        flags: MessageFlags.Ephemeral,
      }).catch(() => null);
    }

    const sub = args[0]?.toLowerCase();
    let targetTab = "overview";
    if (sub === "trigger" || sub === "triggers" || sub === "ar") targetTab = "triggers";
    else if (sub === "reaction" || sub === "reactions" || sub === "autoreact") targetTab = "reactions";
    else if (sub === "sticky" || sub === "stickymessage") targetTab = "sticky";
    else if (sub === "prefix" || sub === "setprefix") targetTab = "prefix";
    else if (sub === "help" || sub === "commands") targetTab = "commands";

    const configContainer = buildConfigurationContainer(message.guild, targetTab);

    return message.reply({
      components: [configContainer],
      flags: MessageFlags.IsComponentsV2,
      allowedMentions: { repliedUser: false },
    }).catch(() => null);
  },
};
